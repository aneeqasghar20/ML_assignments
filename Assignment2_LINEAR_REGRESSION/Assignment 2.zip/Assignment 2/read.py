import pandas
import matplotlib.pyplot as plt
import numpy as np

df = pandas.read_csv('kc_house_data.csv')
print(df)

#plt.scatter(df.price,df.sqft_living)
